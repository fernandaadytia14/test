<?php
include '../konfigurasi/koneksi.php';

if ($_POST['act'] == 'simpan_peserta') {
  # code...
  $sekolah = $_POST['sekolah'];
  $gugus = $_POST['gugus'];
  $koordinator = $_POST['koordinator'];
  $kontakperson = $_POST['kontakperson'];

  $sql = mysqli_query($koneksi, "INSERT INTO peserta VALUES ('', '$sekolah', '$gugus', '$koordinator', '$kontakperson')");

  if ($sql) {
    # code...
    $res = [
      'status' => 'berhasil'
    ];
  } else {
    # code...
    $res = [
      'status' => 'gagal'
    ];
  }

  echo json_encode($res);
}
