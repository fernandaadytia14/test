<?php
include '../konfigurasi/koneksi.php';

if ($_POST['act'] == 'simpan_nilai') {
  # code...
  $id_peserta = $_POST['peserta'];
  $id_mata_lomba = $_POST['matalomba'];
  $nilai = $_POST['nilai'];

  $sql = mysqli_query($koneksi, "INSERT INTO nilai VALUES('', '$id_peserta', '$id_mata_lomba', '$nilai')");

  if ($sql) {
    # code...
    $rest = [
      'pesan' => 'berhasil'
    ];
  } else {
    $rest = [
      'pesan' => 'gagal'
    ];
  }
  echo json_encode($rest);
}
