function simpan_nilai() {
  var peserta = $('#peserta').val();
  var matalomba = $('#matalomba').val();
  var nilai = $('#nilai').val();

  if (peserta == '' || matalomba == '' || nilai == '') {
    alert('data tidak boleh kosong');
  } else if (nilai > 100) {
    alert('nilai tidak boleh lebih dari 100')
  } else {
    $.ajax({
      method: 'post',
      url: 'proses/nilai.php',
      data: {
        peserta: peserta,
        matalomba: matalomba,
        nilai: nilai,
        act: 'simpan_nilai'
      },
      dataType: 'json',
      success: function (response) {
        if (response.pesan == "berhasil") {
          alert('data berhasil disimpan');
          window.location.href = window.location.href;
        } else {
          alert('data gagal disimpan');
          window.location.href = window.location.href;
        }
      }
    })
  }
}