var url = 'proses/peserta.php';

$(function () {
  $('#tbl').DataTable();
})

function simpan() {
  var sekolah = $('#sekolah').val();
  var gugus = $('#gugus').val();
  var koordinator = $('#koordinator').val();
  var kontakperson = $('#kontakperson').val();

  if (sekolah == '' || gugus == '' || koordinator == '' || kontakperson == '') {
    alert('data tidak boleh kosong')
  } else {
    $.ajax({
      type: "post",
      url: url,
      data: {
        sekolah: sekolah,
        gugus: gugus,
        koordinator: koordinator,
        kontakperson: kontakperson,
        act: 'simpan_peserta'
      },
      dataType: "json",
      success: function (response) {
        if (response.status == 'berhasil') {
          alert('data berhasil disimpan');
          window.location.href = window.location.href;
        }

      }
    })
  }
}