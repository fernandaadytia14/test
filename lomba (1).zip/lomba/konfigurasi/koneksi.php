<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'lomba_kegiatan_pramuka');

if (!$koneksi) {
  # code...
  die("Gagal koneksi ke database: " . mysqli_connect_error());
}
