<div class="row">

  <!-- Area Chart -->
  <div class="col-xl-12">
    <div class="card shadow mb-4">
      <!-- Card Header - Dropdown -->
      <div class="card-header">
        <h6 class="m-0 font-weight-bold text-primary">Earnings Overview</h6>
      </div>
      <!-- Card Body -->
      <div class="card-body">

      </div>
    </div>
  </div>

</div>