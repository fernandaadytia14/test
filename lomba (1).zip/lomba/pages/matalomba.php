<div class="modal fade" id="input" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Input data peserta</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>

      <div class="modal-body">
        <table class="table">
          <tr>
            <td>Nama sekolah</td>
            <td>
              <input type="text" id="sekolah" class="form-control">
            </td>
          </tr>
          <tr>
            <td>Nama gugus</td>
            <td>
              <input type="text" id="gugus" class="form-control">
            </td>
          </tr>
          <tr>
            <td>Nama koordinator</td>
            <td>
              <input type="text" id="koordinator" class="form-control">
            </td>
          </tr>
          <tr>
            <td>Kontak person</td>
            <td>
              <input type="text" id="kontakperson" class="form-control">
            </td>
          </tr>
        </table>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" onclick="simpan()">Simpan data</button>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <!-- Area Chart -->
  <div class="col-xl-12">
    <div class="card shadow mb-4">
      <!-- Card Header - Dropdown -->
      <div class="card-header">
        <h6 class="m-0 font-weight-bold text-primary">Data Matalomba</h6>
      </div>
      <!-- Card Body -->
      <div class="card-body">
        <!-- <button class="btn btn-primary float-right mb-2" data-toggle="modal" data-target="#input">Tambah Data</button> -->
        <div class="table-responsive">

          <table class="table table-bordered" id="tbl" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="7%">No.</th>
                <th>Matalomba</th>
                <th width="7%">#</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th width="7%">No.</th>
                <th>Matalomba</th>
                <th width="7%">#</th>
              </tr>
            </tfoot>
            <tbody>
              <?php
              $sql = mysqli_query($koneksi, "SELECT * FROM mata_lomba");

              $no = 1;
              while ($a = mysqli_fetch_array($sql)) :
              ?>
                <tr>
                  <td><?= $no; ?></td>
                  <td><?= $a['mata_lomba']; ?></td>

                  <td>
                    <button class=" btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                  </td>
                </tr>

              <?php
                $no++;
              endwhile;
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>

<script src="js/peserta.js"></script>