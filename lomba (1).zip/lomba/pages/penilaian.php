<div class="row">
  <!-- Area Chart -->
  <div class="col-xl-12">
    <div class="card shadow mb-4">
      <!-- Card Header - Dropdown -->
      <div class="card-header">
        <h6 class="m-0 font-weight-bold text-primary">Data Penilaian</h6>
      </div>
      <!-- Card Body -->
      <div class="card-body">
        <!-- <button class="btn btn-primary float-right mb-2" data-toggle="modal" data-target="#input">Tambah Data</button> -->

        <table class="table">
          <tr>
            <td>Peserta</td>
            <td>
              <select name="" id="peserta" class="form-control">
                <option disabled selected></option>
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM peserta");
                while ($a = mysqli_fetch_array($sql)) :
                ?>

                  <option value="<?= $a['id_peserta']; ?>"><?= $a['nama_sekolah']; ?></option>
                <?php endwhile ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>Matalomba</td>
            <td>
              <select name="" id="matalomba" class="form-control">
                <option disabled selected></option>
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM mata_lomba");
                while ($a = mysqli_fetch_array($sql)) :
                ?>

                  <option value="<?= $a['id_mata_lomba']; ?>"><?= $a['mata_lomba']; ?></option>
                <?php endwhile ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>Nilai</td>
            <td>
              <input type="text" name="" id="nilai" class="form-control">
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <button class="btn btn-primary btn-block" onclick="simpan_nilai()">Simpan nilai</button>
            </td>
          </tr>
        </table>
        <div class="table-responsive">

          <table class="table table-bordered" id="tbl" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="7%">No.</th>
                <th>Peserta</th>
                <th>Matalomba</th>
                <th>Nilai</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th width="7%">No.</th>
                <th>Peserta</th>
                <th>Matalomba</th>
                <th>Nilai</th>
              </tr>
            </tfoot>
            <tbody>
              <?php
              $sql = mysqli_query($koneksi, "
              SELECT
                nilai.id_nilai,
                nilai.id_peserta,
                peserta.nama_sekolah,
                nilai.id_mata_lomba,
                mata_lomba.mata_lomba,
                nilai.nilai
                FROM
                mata_lomba
                INNER JOIN nilai ON nilai.id_mata_lomba = mata_lomba.id_mata_lomba
                INNER JOIN peserta ON nilai.id_peserta = peserta.id_peserta
              ");

              $no = 1;
              while ($a = mysqli_fetch_array($sql)) :
              ?>
                <tr>
                  <td><?= $no; ?></td>
                  <td><?= $a['nama_sekolah']; ?></td>
                  <td><?= $a['mata_lomba']; ?></td>
                  <td><?= $a['nilai']; ?></td>
                </tr>

              <?php
                $no++;
              endwhile;
              ?>
            </tbody>
          </table>

          <button class="btn btn-danger btn-block mt-3">Cetak nilai</button>
        </div>
      </div>
    </div>
  </div>

</div>

<script src="js/nilai.js"></script>