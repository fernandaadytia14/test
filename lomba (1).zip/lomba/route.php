<?php
if ($_GET['page'] == 'home' || $_GET['page'] == '') {
  include 'pages/home.php';
}

if ($_GET['page'] == 'data-peserta') {
  include 'pages/data-peserta.php';
}
if ($_GET['page'] == 'matalomba') {
  include 'pages/matalomba.php';
}
if ($_GET['page'] == 'penilaian') {
  include 'pages/penilaian.php';
}
